//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AccessEnum.rc
//
#define IDI_MYCOMPUTER                  201
#define IDI_FOLDERCLOSED                203
#define IDI_FOLDEROPEN                  204
#define IDI_STRING                      205
#define IDI_BINARY                      206
#define IDI_UPARROW                     330
#define IDI_DOWNARROW                   331
#define IDC_REFRESH                     1081
#define IDC_LIST                        1090
#define IDC_EXPORT                      1091
#define IDC_LINK                        1092
#define IDC_DESCRIPTION                 1095
#define IDC_STATUS                      1098
#define IDC_PATH                        1100
#define IDC_QUIT                        1101
#define IDC_BROWSE_FILE                 1102
#define IDC_BROWSE_REG                  1103
#define IDC_EDIT                        1104
#define IDC_TREE                        1106
#define IDC_ABOUT                       40001
#define IDC_COMPARE                     40030
#define IDC_EXCLUDE                     40031
#define IDC_PROPERTIES                  40032
#define IDC_EXPLORE                     40033
#define IDC_FILEOPTIONS                 40034
#define IDC_HELPCONTENTS                40035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         40036
#define _APS_NEXT_CONTROL_VALUE         1108
#define _APS_NEXT_SYMED_VALUE           106
#endif
#endif
