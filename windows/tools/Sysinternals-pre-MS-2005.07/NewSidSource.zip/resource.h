//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by sid.rc
//
#define IDC_ABOUT                       3
#define IDC_NAME                        3
#define IDC_SYNC                        4
#define IDI_ICON2                       114
#define IDC_PATHNAME                    1002
#define IDC_SHOWHELP                    1002
#define IDC_NAMESELECT                  1003
#define IDC_BACK                        1003
#define IDC_DOMAINSELECT                1004
#define IDC_ADDDOMAIN                   1005
#define IDC_DCNAME                      1006
#define IDC_NEXT                        1007
#define IDC_RANDOM                      1007
#define IDC_COPY                        1008
#define IDC_SPECIFIC                    1009
#define IDC_SID                         1010
#define IDC_COMPUTER                    1011
#define IDC_BROWSE                      1012
#define IDC_CHECKRENAME                 1013
#define IDC_COMPUTERNAME                1014
#define IDC_RANDOMPROGRESS              1015
#define IDC_OPERATION                   1016
#define IDC_CURRENTSID                  1020
#define IDC_NEWSID                      1021
#define IDC_RENAME                      1022
#define IDC_REBOOT                      1023
#define IDC_CURNAME                     1024
#define IDC_LINK                        1025
#define IDC_CURSID                      1025
#define IDC_TITLE                       1103
#define IDC_PAGEFRAME                   1104
#define IDC_UPPERLINE                   1105
#define IDC_EXTTITLE                    1106
#define IDC_WATERMARK                   1107
#define IDC_BANNER                      1108
#define IDC_EXTPAGEFRAME                1109
#define IDC_WHITEBACKGROUND             1110
#define IDC_SUBTITLE                    1111

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        115
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
